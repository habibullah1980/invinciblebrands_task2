<?php
/**
 * Add the field to the checkout
 */
add_action( 'woocommerce_after_order_notes', 'gender_checkout_field' );

function gender_checkout_field( $checkout ) {

    echo '<div id="gender_checkout_field">';

    woocommerce_form_field( 'gender_field', array(
        'type'          => 'text',
        'class'         => array('gender-class form-row-wide'),
        'label'         => __('Gender'),
        'placeholder' => __('(m/f/x)'),
        'required'  => true,
        ), $checkout->get_value( 'gender_field' ));

    echo '</div>';
}

/**
 * Process the checkout
 */
add_action('woocommerce_checkout_process', 'gender_checkout_field_process');

function gender_checkout_field_process() {
    // Check if set, if its not set add an error.
    if ( empty( $_POST['gender_field'] ) ) {
        wc_add_notice( __( 'Please enter gender.' ), 'error' );
    }
}
add_action( 'woocommerce_after_order_notes', 'birth_checkout_field' );

function birth_checkout_field( $checkout ) {
    echo '<div id="birth_checkout_field">';
    woocommerce_form_field( 'birth_field', array(
        'type'          => 'date',
        'class'         => array('birth-class form-row-wide'),
        'label'         => __('Birthday'),
        'required'  => true,
        ), $checkout->get_value( 'birth_field' ));

    echo '</div>';

}
add_action('woocommerce_checkout_process', 'birth_checkout_field_process');
function birth_checkout_field_process() {
    // Check if set, if its not set add an error.
    if ((empty( $_POST['birth_field'] ) )) {
        wc_add_notice( __( 'Please enter dob.' ), 'error' );
    }else {
        $date2 = $_POST['birth_field'];
        $date1 = date("Y-m-d");
        $diff = abs(strtotime($date2) - strtotime($date1));
        $years = floor($diff / (365*60*60*24));
        if( $years < 18 ) {
        wc_add_notice( __( 'sorry, you are not 18 years old' ), 'error' );
        }   
        }   
}
    
 ?>


